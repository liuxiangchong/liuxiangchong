function basis=clr2ilr(n)
% The basis transfering CLR data to ILR data
% This basis is from Egozcue, 2003. Mathematical Geology.
basis=zeros(n-1,n);
for i=1:n-1
    for j=1:i
        basis(i,j)=sqrt(i/(i+1))/i;
    end
    basis(i,i+1)=-1*sqrt(i/(i+1));
end
basis=basis';
end
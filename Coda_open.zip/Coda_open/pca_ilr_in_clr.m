function pca_ilr_in_clr
clear
clc
% get the element names from a given text only containing the elements
% get the element names from text, 'r' means reading
fid = fopen('elements.txt','r');
% '%s' reads a whitespace separated string
A = textscan(fid, '%s')
fclose(fid)
elements= A{1}';
% the number of elements should be consistent with the number of columns of
% content data
n=length(elements);
% get the element content data from another text only containing contents
% The nth column of content data corresponds to the nth element
data_raw1=textread('contents.txt');
data_raw2=data_raw1(:,1:n);
data_raw=data_raw2;
[m,n]=size(data_raw);
% for in case when some data are zeros or negative
% This theshold would not alter PCA results
threshold = 1e-5;
for i=1:m
    for j=1:n
        if data_raw(i,j)<=0
            data_raw(i,j)=threshold;
        end
    end
end
%--------First CLR then CLR to ILR using the basis-------------------------
data_clr=zeros(m,n);
% geometry is the geometric average of each group of data
for i=1:m
    geometry=(prod(data_raw(i,:)))^(1/n);
    for j=1:n
         data_clr(i,j)=log(data_raw(i,j)/geometry);
    end
end
% The basis transfering CLR data to ILR data
basis=clr2ilr2(n);
data_ilr=data_clr*basis;
corre_ilr=corrcoef(data_ilr);
[load_ilr,latent_ilr]=pcacov(corre_ilr);
% Eigenvalue
figure
plot([1:n-1]',latent_ilr,'b.','Markersize',20)
xlabel('Eigenvalue Number','fontsize',18)
ylabel('Eigenvalue','fontsize',18)
set(gca,'fontSize',18)
print(gcf, '-dtiff','-r400','ILR_eigenvalues.tif')
% calculate the loadings and scores in CLR space
load_clr=basis*load_ilr;
data_std=zscore(data_clr);
score_clr=data_std*load_clr;

% % plot the ii component scores vs the jj  component scores
% ii,jj,the two principle components
% elements={'Au','As','Sb','Ag','Ti','V','Cr','Co','Cu','Zn','W','Pb'};

%to better shown all the elements
% load_clr=load_clr*2
%��1�͵�2���ɷַ���
ii=1;
jj=2;
max1=max(score_clr(:,ii));
max2=abs(min(score_clr(:,ii)));
if max1>max2
    max3=max1;
else
    max3=max2;
end
for k=1:m
    score_clr(k,ii)=score_clr(k,ii)/max3;
end
max1=max(score_clr(:,jj));
max2=abs(min(score_clr(:,jj)));
if max1>max2
    max3=max1;
else
    max3=max2;
end
for k=1:m
    score_clr(k,jj)=score_clr(k,jj)/max3;
end
figure
plot(score_clr(:,ii),score_clr(:,jj),'k.','MarkerSize',6)
hold on
for k=1:n
    plot([0,load_clr(k,ii)],[0,load_clr(k,jj)],'r','linewidth',1.0)
    hold on
end
plot([0,0],[-1,1],'k--','linewidth',0.5)
hold on
plot([-1,1],[0,0],'k--','linewidth',0.5)
% axis([-0.8,0.8,-0.8,0.8])
%  you can alter the positions of the variables by
% load_clr(1,ii)=load_clr(1,ii)-0.05;

text(load_clr(:,ii),load_clr(:,jj),elements,'fontSize',10,'fontname','times new Roman','color','blue')

xlabel('The 1^s^t principle component','fontsize',12,'fontname','times new Roman')
ylabel('The 2^n^d principle component','fontsize',12,'fontname','times new Roman')
% set(gca,'fontSize',18,'fontname','times new Roman')
title('ILR transformation','fontsize',12,'fontname','times new Roman')
% out put the figure with a format of tif
% '-r400' means a resolution of 400 dpi
print(gcf, '-dtiff','-r400','Longlin_ilr_biplot_p1_p2.tif')


%�����͵������ɷַ���
ii=3;
jj=4;
max1=max(score_clr(:,ii));
max2=abs(min(score_clr(:,ii)));
if max1>max2
    max3=max1;
else
    max3=max2;
end
for k=1:m
    score_clr(k,ii)=score_clr(k,ii)/max3;
end
max1=max(score_clr(:,jj));
max2=abs(min(score_clr(:,jj)));
if max1>max2
    max3=max1;
else
    max3=max2;
end
for k=1:m
    score_clr(k,jj)=score_clr(k,jj)/max3;
end
figure
plot(score_clr(:,ii),score_clr(:,jj),'k.','MarkerSize',6)
hold on
for k=1:n
    plot([0,load_clr(k,ii)],[0,load_clr(k,jj)],'r','linewidth',1.0)
    hold on
end
plot([0,0],[-1,1],'k--','linewidth',0.5)
hold on
plot([-1,1],[0,0],'k--','linewidth',0.5)
% axis([-0.8,0.8,-0.8,0.8])


text(load_clr(:,ii),load_clr(:,jj),elements,'fontSize',10,'fontname','times new Roman','color','blue')
xlabel('The 3^r^d principle component','fontsize',12,'fontname','times new Roman')
ylabel('The 4^t^h principle component','fontsize',12,'fontname','times new Roman')

title('ILR transformation','fontsize',12,'fontname','times new Roman')
print(gcf, '-dtiff','-r400','Longlin_ilr_biplot_p3_p4.tif')

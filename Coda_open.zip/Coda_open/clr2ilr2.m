function basis=clr2ilr2(n)
% The basis transfering CLR data to ILR data
% This basis is from the R package robcomposition
basis0=zeros(n-1,n);
basis=zeros(n,n-1);
for i=1:n-1
    for j=1:i
        basis0(i,j)=sqrt(i/(i+1))/i;
    end
    basis0(i,i+1)=-1*sqrt(i/(i+1));
end
basis0=basis0';
for i=1:n
    for j=1:n-1
        basis(n-i+1,n-1-j+1)=basis0(i,j);
    end
end        
end